package com.example.FutsalFever;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FutsalFeverApplication {

	public static void main(String[] args) {
		SpringApplication.run(FutsalFeverApplication.class, args);
	}

}
